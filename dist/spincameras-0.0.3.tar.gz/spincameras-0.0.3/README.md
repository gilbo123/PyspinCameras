# SpinCameras
Easy access for Spinakker-based (FLIR) machine vision cameras. 

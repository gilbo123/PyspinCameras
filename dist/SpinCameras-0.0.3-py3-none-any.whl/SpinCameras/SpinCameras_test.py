from time import sleep
from typing import Any
from Cameras import Camera, Cameras
import PySpin

system: PySpin.System = PySpin.System.GetInstance()
cameras: Cameras = Cameras(system=system)

print(cameras)

cameras.initialise_cameras()

for cam in cameras:
    camera: Camera = cameras.get_camera_by_serial(cam.device_serial_number)
    print(camera)

    # cam.set_pixel_format(PySpin.PixelFormat_Mono16) # good - success


    del camera    
    del cam


cameras.deinitialise_cameras()
cameras.release_all_cameras()
del cameras

system.ReleaseInstance()
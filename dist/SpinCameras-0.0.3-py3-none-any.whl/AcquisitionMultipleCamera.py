"""Module to capture images from 2 Flir USB cameras. """

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from queue import Queue
from threading import Thread
from time import sleep
from typing import Optional

import cv2
from PySpin import (
    SPINNAKER_COLOR_PROCESSING_ALGORITHM_HQ_LINEAR,
    ImageProcessor,
    ImagePtr,
    LibraryVersion,
    PixelFormat_RGB8Packed,
    System,
)

from SpinCameras.Cameras import Camera, Cameras


@dataclass
class MultipleCameraImageCallBack:
    """Callback to save images"""

    save_folder: str
    cameras: Cameras
    index: int

    def __post_init__(self) -> None:
        """
        Post-initialisation method
        """

        # get the camera using `index`
        self.camera: Camera = self.cameras[self.index]

        # Create ImageProcessor instance for post processing images
        self._processor = ImageProcessor()

        # Set default image processor color processing method
        #
        # *** NOTES ***
        # By default, if no specific color processing algorithm is set, the image
        # processor will default to NEAREST_NEIGHBOR method.
        self._processor.SetColorProcessing(
            SPINNAKER_COLOR_PROCESSING_ALGORITHM_HQ_LINEAR
        )

    def __call__(self, image_converted, filename: str) -> None:
        """
        Callback to save images

        :param image_converted: Image
        :type image_converted: Image
        :param filename: Filename
        :type filename: str
        """

        print(f"Callback CLASS - Image {filename} saved.")

        # convert to numpy array
        image_converted_numpy = image_converted.GetNDArray()
        # convert BGR to RGB
        image_converted_numpy = cv2.cvtColor(image_converted_numpy, cv2.COLOR_BGR2RGB)  # type: ignore

        # cv2.imshow(cam_id, image_converted_numpy)  # type: ignore
        # cv2.waitKey(1)  # type: ignore
        # save the image
        cv2.imwrite(f"{self.save_folder}/{filename}", image_converted_numpy)  # type: ignore

        ir_count: int = int(filename.split("_")[1].split("-")[1].strip())

        if self.camera.device_serial_number == TOP:
            print("TOP")
            # trigger the ir camera
            ir_top = self.cameras.get_camera_by_serial(IR_TOP)
            # get image on a thread
            t = Thread(target=self.get_image_thread, args=(ir_top, ir_count, 0.1))
            t.start()

        elif self.camera.device_serial_number == BOTTOM:
            print("BOTTOM")
            # trigger the ir camera
            ir_bot = self.cameras.get_camera_by_serial(IR_BOTTOM)
            # get image on a thread
            t = Thread(target=self.get_image_thread, args=(ir_bot, ir_count, 0.1))
            t.start()

    def get_image_thread(self, camera: Camera, count: int, delay: float) -> None:
        """
        Get the image from the camera

        :param camera: Camera object
        :type camera: Camera
        """

        sleep(delay)
        camera.execute_software_trigger()
        image = camera.get_next_image()

        if image is not None:
            image_converted: ImagePtr = image
            try:
                # Convert image colour format
                image_converted = self._processor.Convert(image, PixelFormat_RGB8Packed)
            except:
                pass
            # convert to numpy array
            image_converted_numpy = image_converted.GetNDArray()
            # convert BGR to RGB
            image_converted_numpy = cv2.cvtColor(image_converted_numpy, cv2.COLOR_BGR2RGB)  # type: ignore

            dt: str = datetime.now().strftime("%Y-%m-%dT%H:%M:%S:%f")
            if camera.device_serial_number:
                filename = f"cam-{camera.device_serial_number}_img-{count}_{dt}.jpg"

            else:  # if serial number is empty
                filename = f"img-{count}_{dt}.jpg"
            # cv2.imshow(cam_id, image_converted_numpy)  # type: ignore
            # cv2.waitKey(1)  # type: ignore
            # save the image
            cv2.imwrite(f"{self.save_folder}/{filename}", image_converted_numpy)  # type: ignore


@dataclass
class CaptureMultipleCameras:
    """Capture images from multiple cameras and save/show them using cv2 package"""

    save_folder: str

    def set_parameters(self, cameras: Cameras) -> bool:
        """
        Set the parameters for the cameras

        :param cameras: Cameras object
        :type cameras: Cameras
        :return: Errors - True if error setting any parameters, False otherwise
        :rtype: bool
        """

        # errors
        params_set: list[bool] = []

        for i, camera in enumerate(cameras):
            params_set.append(camera.set_acquisition_mode(acq_mode="continuous"))
            params_set.append(camera.set_frame_rate(frame_rate=20.0))
            params_set.append(camera.set_stream_buffer_mode())
            # params_set.append(camera.set_trigger_mode(trigger_mode="off"))
            # params_set.append(
            #     camera.set_trigger_mode(trigger_mode="on", source="software")
            # )
            if camera.device_serial_number == TOP:
                params_set.append(camera.set_gain(gain_mode="off", gain=5.0))
                params_set.append(camera.set_exposure(exp_mode="off", exp_time=1000.0))
                # params_set.append(
                #     camera.set_white_balance(
                #         bal_mode="off", red_selector=1.94, blue_selector=2.52
                #     )
                # )
                params_set.append(camera.set_white_balance(bal_mode="continuous"))
                params_set.append(
                    camera.set_trigger_mode(
                        trigger_mode="on", source="hardware", line=3
                    )
                )
                # set a callback
                params_set.append(
                    camera.set_callback_function(
                        MultipleCameraImageCallBack(
                            save_folder=self.save_folder, cameras=cameras, index=i
                        )
                    )
                )
            elif camera.device_serial_number == BOTTOM:
                params_set.append(camera.set_gain(gain_mode="off", gain=5.0))
                params_set.append(camera.set_exposure(exp_mode="off", exp_time=1000.0))
                # params_set.append(
                #     camera.set_white_balance(
                #         bal_mode="off", red_selector=1.94, blue_selector=2.52
                #     )
                # )
                params_set.append(camera.set_white_balance(bal_mode="continuous"))
                params_set.append(
                    camera.set_trigger_mode(
                        trigger_mode="on", source="hardware", line=2
                    )
                )
                # set a callback
                params_set.append(
                    camera.set_callback_function(
                        MultipleCameraImageCallBack(
                            save_folder=self.save_folder, cameras=cameras, index=i
                        )
                    )
                )

            # IR - TOP
            elif camera.device_serial_number == IR_TOP:
                params_set.append(camera.set_gain(gain_mode="off", gain=20.0))
                params_set.append(camera.set_exposure(exp_mode="off", exp_time=300.0))
                params_set.append(
                    camera.set_trigger_mode(trigger_mode="on", source="software")
                )

            # IR - BOTTOM
            elif camera.device_serial_number == IR_BOTTOM:
                params_set.append(camera.set_gain(gain_mode="off", gain=20.0))
                params_set.append(camera.set_exposure(exp_mode="off", exp_time=300.0))
                params_set.append(
                    camera.set_trigger_mode(trigger_mode="on", source="software")
                )
            else:
                print("Camera serial number not recognised.")
                return False

            # get the serial number
            s_number: str = camera.device_serial_number

            print(
                f"Camera {s_number} parameters {'not set' if False in params_set else 'set'}."
            )

            # print device temperature
            print(f"Device temperature: {camera.device_temperature}")

            # delete the reference
            del camera

        return False in params_set

    def run_multiple_cameras(self, q: Optional[Queue] = None) -> None:
        """
        Run the multiple cameras module


        :return: None
        :rtype: None
        """

        # Retrieve singleton reference to system object
        self.system: System = System.GetInstance()
        # Get current library version
        version: LibraryVersion = self.system.GetLibraryVersion()
        print(
            "Library version: %d.%d.%d.%d"
            % (version.major, version.minor, version.type, version.build)
        )
        # get the cameras
        cameras: Cameras = Cameras(
            system=self.system,
            queue=q if q else None,
            save_folder=self.save_folder,
            verbose=True,
        )
        # check if cameras are available
        if len(cameras) == 0:
            return

        ### INIT
        cameras.initialise_cameras()
        ### SET PARAMETERS
        error: bool = self.set_parameters(cameras)
        ### START CAPTURE
        if not error:
            # performs start and stop acquisition functions
            cameras.acquire_images()
        else:
            print("Error setting parameters. Exiting...")

        del cameras
        # release once all cameras are deleted
        self.system.ReleaseInstance()


if __name__ == "__main__":

    # create the module
    cmc: CaptureMultipleCameras = CaptureMultipleCameras(
        save_folder="/home/gil/Documents/strawberry_images"
    )

    TOP = "24132701"
    BOTTOM = "24025827"
    IR_TOP = "24236109"
    IR_BOTTOM = "24236108"

    # run the module
    cmc.run_multiple_cameras()

    # make a new queue
    # queue: Queue = Queue()

    # run on a thread
    # t = Thread(target=cmc.run_multiple_cameras, args=(queue,))
    # t.start()
    # t.join()

    # # monitor the queue
    # k: int = 0
    # while not queue.empty():
    #     k += 1
    #     item = queue.get()
    #     print(f"Item {k}: {item['filename']}")
